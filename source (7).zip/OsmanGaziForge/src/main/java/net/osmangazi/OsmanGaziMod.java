package net.osmangazi;

import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(OsmanGaziMod.MODID)
public final class OsmanGaziMod {
    public static final String MODID = "osmangazi";

    public OsmanGaziMod(FMLJavaModLoadingContext context) {
        var bus = context.getModBusGroup();
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModTabs.TABS.register(bus);
        EntityAttributeCreationEvent.getBus(bus).addListener(ModEntities::attributes);
        SpawnPlacementRegisterEvent.getBus(bus).addListener(ModEntities::spawnPlacements);
    }
}
