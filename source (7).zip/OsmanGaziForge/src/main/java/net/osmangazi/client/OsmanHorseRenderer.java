package net.osmangazi.client;

import net.minecraft.client.model.animal.equine.HorseModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.AbstractHorseRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.state.EquineRenderState;
import net.minecraft.resources.Identifier;
import net.osmangazi.OsmanHorse;

public class OsmanHorseRenderer extends AbstractHorseRenderer<OsmanHorse, OsmanHorseRenderer.State, HorseModel<OsmanHorseRenderer.State>> {
    public static class State extends EquineRenderState {
        public Identifier texture;
    }

    public OsmanHorseRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HorseModel<>(ctx.bakeLayer(ModelLayers.HORSE)), new HorseModel<>(ctx.bakeLayer(ModelLayers.HORSE)));
    }

    @Override
    public State createRenderState() { return new State(); }

    @Override
    public void extractRenderState(OsmanHorse e, State s, float partial) {
        super.extractRenderState(e, s, partial);
        s.texture = e.texture();
    }

    @Override
    public Identifier getTextureLocation(State s) { return s.texture; }
}
